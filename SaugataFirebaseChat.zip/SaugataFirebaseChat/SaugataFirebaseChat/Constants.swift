//
//  Constants.swift
//  SaugataFirebaseChat
//
//  Created by Apple on 18/12/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import Firebase
struct Constants {
    struct refs {
        static let databaseRoot = Database.database().reference()
        static let databaseChats = databaseRoot.child("chats")
    }
}
