//
//  Bridging-Header.h
//  SaugataFirebaseChat
//
//  Created by Apple on 18/12/19.
//  Copyright © 2019 Apple. All rights reserved.
//

#ifndef Bridging_Header_h
#define Bridging_Header_h
#import <JSQMessagesViewController/JSQMessages.h>

#endif /* Bridging_Header_h */
